import React from 'react';
import { Link } from "react-router-dom";
import { makeStyles } from '@material-ui/core/styles';
import Box from '@material-ui/core/Box';
import Button from '@material-ui/core/Button';
import CloudUploadIcon from '@material-ui/icons/CloudUpload';

const useStyles = makeStyles((theme) => ({
  root: {
    '& > *': {
      margin: theme.spacing(1),
    },
  },
  input: {
    display: 'none',
  },
}));



function App() {
  const classes = useStyles();

  return (
    <Box paddingLeft={2} paddingRight={2} >
      <Box borderBottom={1} padding={4} style={{borderColor:'#a9a9a9'}}>
        <h1>PDF Template Creation</h1>
      </Box>
      <Box bgcolor="white" boxShadow={3} margin={2}>
        
        <Box display="flex" justifyContent="center" className={classes.root}>
         
            <input accept="application/pdf" className={classes.input} id="contained-button-file" multiple type="file"/>
            <label htmlFor="contained-button-file">
              <Button variant="contained" color="primary" component="span" startIcon={<CloudUploadIcon/>}>
                Upload a PDF file
              </Button>
            </label>
     
        </Box>

        <Box display="flex" justifyContent="center" m={2}>
        <div className={classes.root}>
            <Link to="/newtemplate">
            <Button variant="contained" color="primary" component="span">
                  New Template
            </Button>
            </Link>
          <Button variant="contained" color="warning" component="span" >
                Existing Template
          </Button>
          </div>
        </Box>
      </Box>
    </Box>
  );
}

export default App;
