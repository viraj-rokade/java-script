import React from 'react';
import './App.css';
import { Switch, Route } from 'react-router-dom';
import Home from './pages/home';
import NewTemplate from './pages/newtemplate';
import ExTemplate from './pages/existingtemplate';

const App = () => (
  <div className='app'>
    <Main />
  </div>
);

const Main = () => (
   
      <Switch> {/* The Switch decides which component to show based on the current URL.*/}
        <Route exact path='/' component={Home}></Route>
        <Route exact path='/newtemplate' component={NewTemplate}></Route>
        <Route exact path='/existingtemplate' component={ExTemplate}></Route>
      </Switch>
);

export default App;